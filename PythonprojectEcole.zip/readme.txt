Readme

Ajouter les 3 fichiers .py dans le meme dossier
Créer un dossier nommé data et copier les 2 fichiers "films.txt" et "users.txt" a l'interieur
executer main.py

